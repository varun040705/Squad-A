# manufacturing/config.py -- STARTER DEPTH. Applies per factory production batch (precast/fabrication).
MANUFACTURING_CONFIG = {
    "dimensional_tolerance": {"unit": "mm", "min_allowed": -3, "max_allowed": 3, "standard_ref": "Factory QC Spec (placeholder)", "test_method": "Physical Measurement", "check_type": "numeric"},
    "factory_production_control_certified": {"standard_ref": "FPC Certificate", "test_method": "Document Verification", "check_type": "boolean"},
    "weld_quality": {"standard_ref": "AWS D1.1 (placeholder)", "test_method": "Weld Inspection", "check_type": "categorical", "allowed_values": ["Accept"]},
    "surface_treatment_qa": {"standard_ref": "Factory QC Spec (placeholder)", "test_method": "Coating/Finish Inspection", "check_type": "categorical", "allowed_values": ["Compliant"]},
    "factory_test_report_available": {"standard_ref": "Factory Acceptance Test (FAT)", "test_method": "Document Verification", "check_type": "boolean"},
}
