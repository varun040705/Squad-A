# core/engine.py
# Generic engine -- takes ANY config dict + ANY QASample, runs every item's
# check, returns one report. Used identically by every material/category.

from core.checks import check_numeric, check_categorical, check_boolean, check_gradation

CHECK_FUNCTIONS = {
    "numeric": check_numeric,
    "categorical": check_categorical,
    "boolean": check_boolean,
    "gradation": check_gradation,
}

def run_qa(config, sample):
    report = {
        "sample_id": sample.sample_id,
        "source": sample.source,
        "results": [],
        "overall_status": "PASS",
    }

    for item_name, rules in config.items():
        measured_value = sample.get_value(item_name)

        if measured_value is None:
            result = {
                "item": item_name,
                "status": "MISSING",
                "reason": "No measurement provided for this item",
            }
        else:
            check_type = rules.get("check_type", "numeric")
            check_fn = CHECK_FUNCTIONS[check_type]
            result = check_fn(item_name, measured_value, rules)

        report["results"].append(result)
        if result["status"] in ("FAIL", "MISSING"):
            report["overall_status"] = "FAIL"

    return report
