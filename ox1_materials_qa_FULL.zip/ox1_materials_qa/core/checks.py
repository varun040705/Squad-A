# core/checks.py
# Generic check functions -- work for ANY config, not just Sand.
# check_type in config determines which function engine.py calls.

def check_numeric(item_name, measured_value, rules):
    result = _base_result(item_name, rules)
    result["measured_value"] = measured_value
    result["unit"] = rules.get("unit")

    min_allowed = rules.get("min_allowed")
    max_allowed = rules.get("max_allowed")

    if min_allowed is not None and measured_value < min_allowed:
        result["status"] = "FAIL"
        result["reason"] = f"{measured_value} is below minimum {min_allowed}"
    elif max_allowed is not None and measured_value > max_allowed:
        result["status"] = "FAIL"
        result["reason"] = f"{measured_value} exceeds maximum {max_allowed}"
    else:
        result["status"] = "PASS"
        result["reason"] = "Within acceptable range"
    return result


def check_categorical(item_name, value, rules):
    result = _base_result(item_name, rules)
    result["measured_value"] = value
    allowed = rules.get("allowed_values", [])

    if value in allowed:
        result["status"] = "PASS"
        result["reason"] = f"'{value}' is within allowed categories {allowed}"
    else:
        result["status"] = "FAIL"
        result["reason"] = f"'{value}' is not in allowed categories {allowed}"
    return result


def check_boolean(item_name, value, rules):
    result = _base_result(item_name, rules)
    result["measured_value"] = value

    if value is True:
        result["status"] = "PASS"
        result["reason"] = "Confirmed"
    else:
        result["status"] = "FAIL"
        result["reason"] = "Not confirmed / documentation missing"
    return result


def check_gradation(item_name, percent_passing_by_sieve, rules):
    result = _base_result(item_name, rules)
    zone_limits = rules.get("zone_limits", {})
    sieve_results = []
    all_pass = True

    for sieve, (low, high) in zone_limits.items():
        value = percent_passing_by_sieve.get(sieve)
        if value is None:
            sieve_results.append({"sieve": sieve, "status": "MISSING"})
            all_pass = False
            continue
        if low <= value <= high:
            sieve_results.append({"sieve": sieve, "value": value, "status": "PASS"})
        else:
            sieve_results.append({"sieve": sieve, "value": value, "status": "FAIL",
                                   "reason": f"{value} outside zone range {low}-{high}"})
            all_pass = False

    result["measured_value"] = percent_passing_by_sieve
    result["sieve_results"] = sieve_results
    result["status"] = "PASS" if all_pass else "FAIL"
    result["reason"] = "All sieves within zone limits" if all_pass else "One or more sieves outside zone limits"
    return result


def _base_result(item_name, rules):
    return {
        "item": item_name,
        "standard_ref": rules.get("standard_ref"),
        "test_method": rules.get("test_method"),
        "status": None,
        "reason": None,
    }
