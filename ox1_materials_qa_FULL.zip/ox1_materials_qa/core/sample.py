# core/sample.py
# Generic sample container -- used for ANY material or category
# (materials, procurement events, manufacturing batches, on-site checks).

class QASample:
    def __init__(self, sample_id, source, measurements):
        """
        sample_id: unique ID (e.g. "SND-2026-001", "PO-2026-014")
        source: where it came from (vendor, site location, batch id, etc.)
        measurements: dict of item_name -> measured/derived/categorical/boolean value
        """
        self.sample_id = sample_id
        self.source = source
        self.measurements = measurements

    def get_value(self, item_name):
        return self.measurements.get(item_name)
