# procurement/config.py -- STARTER DEPTH. Applies per purchase order / delivery event.
PROCUREMENT_CONFIG = {
    "vendor_approved": {"standard_ref": "Approved Vendor List (AVL)", "test_method": "AVL Cross-Check", "check_type": "boolean"},
    "po_verified": {"standard_ref": "Purchase Order Record", "test_method": "PO Cross-Check", "check_type": "boolean"},
    "sample_approved": {"standard_ref": "Sample Approval Record", "test_method": "Sample Approval Check", "check_type": "boolean"},
    "delivery_on_time": {"standard_ref": "Delivery Schedule", "test_method": "Delivery Date Check", "check_type": "boolean"},
    "packaging_intact": {"standard_ref": "Delivery Inspection Checklist", "test_method": "Visual Inspection", "check_type": "boolean"},
    "documentation_complete": {"standard_ref": "Procurement QA Checklist", "test_method": "Document Verification", "check_type": "boolean"},
}
