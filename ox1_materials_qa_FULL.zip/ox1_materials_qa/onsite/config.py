# onsite/config.py -- STARTER DEPTH. Applies per on-site construction check event.
ONSITE_CONFIG = {
    "concrete_slump": {"unit": "mm", "min_allowed": 50, "max_allowed": 150, "standard_ref": "IS 1199 (placeholder)", "test_method": "Slump Cone Test", "check_type": "numeric"},
    "concrete_cube_strength": {"unit": "MPa", "min_allowed": 25, "standard_ref": "IS 516 (placeholder)", "test_method": "Cube Compression Test", "check_type": "numeric"},
    "reinforcement_bar_spacing": {"unit": "mm", "min_allowed": 100, "max_allowed": 300, "standard_ref": "IS 456 (placeholder)", "test_method": "Physical Measurement", "check_type": "numeric"},
    "reinforcement_cover": {"unit": "mm", "min_allowed": 25, "standard_ref": "IS 456 (placeholder)", "test_method": "Cover Meter", "check_type": "numeric"},
    "formwork_alignment_deviation": {"unit": "mm", "max_allowed": 5, "standard_ref": "IS 456 (placeholder)", "test_method": "Plumb/Level Check", "check_type": "numeric"},
    "masonry_plumbness_deviation": {"unit": "mm", "max_allowed": 6, "standard_ref": "IS 2212 (placeholder)", "test_method": "Plumb Line Check", "check_type": "numeric"},
}
