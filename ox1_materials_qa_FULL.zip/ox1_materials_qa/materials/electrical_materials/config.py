# materials/electrical_materials/config.py -- STARTER DEPTH (cables). PLACEHOLDER thresholds.
ELECTRICAL_MATERIALS_CONFIG = {
    "insulation_resistance": {"unit": "MOhm", "min_allowed": 1.0, "standard_ref": "IS 7098 (placeholder)", "test_method": "Insulation Resistance Test", "check_type": "numeric"},
    "voltage_rating_confirmed": {"standard_ref": "IS 7098 (placeholder)", "test_method": "Rating Plate Verification", "check_type": "boolean"},
    "continuity_test": {"standard_ref": "Site QA Checklist", "test_method": "Continuity Test", "check_type": "boolean"},
    "certification": {"standard_ref": "BIS Certification", "test_method": "Document Verification", "check_type": "boolean"},
}
