# materials/concrete/config.py -- STARTER DEPTH (ready-mix/precast). PLACEHOLDER thresholds.
CONCRETE_CONFIG = {
    "slump": {"unit": "mm", "min_allowed": 50, "max_allowed": 150, "standard_ref": "IS 1199 (placeholder)", "test_method": "Slump Cone Test", "check_type": "numeric"},
    "cube_strength_28day": {"unit": "MPa", "min_allowed": 25, "standard_ref": "IS 516 (placeholder)", "test_method": "Cube Compression Test", "check_type": "numeric"},
    "workability": {"standard_ref": "IS 1199 (placeholder)", "test_method": "Visual/Slump Assessment", "check_type": "categorical", "allowed_values": ["Good", "Medium"]},
    "curing_verification": {"standard_ref": "Site QA Checklist", "test_method": "Document Verification", "check_type": "boolean"},
}
