# materials/aggregates/config.py -- STARTER DEPTH (coarse aggregate). PLACEHOLDER thresholds.
AGGREGATES_CONFIG = {
    "crushing_value": {"unit": "%", "max_allowed": 30, "standard_ref": "IS 2386 Part IV (placeholder)", "test_method": "Aggregate Crushing Test", "check_type": "numeric"},
    "impact_value": {"unit": "%", "max_allowed": 30, "standard_ref": "IS 2386 Part IV (placeholder)", "test_method": "Aggregate Impact Test", "check_type": "numeric"},
    "flakiness_index": {"unit": "%", "max_allowed": 35, "standard_ref": "IS 2386 Part I (placeholder)", "test_method": "Flakiness Gauge", "check_type": "numeric"},
    "elongation_index": {"unit": "%", "max_allowed": 35, "standard_ref": "IS 2386 Part I (placeholder)", "test_method": "Elongation Gauge", "check_type": "numeric"},
    "water_absorption": {"unit": "%", "max_allowed": 2.0, "standard_ref": "IS 2386 Part III (placeholder)", "test_method": "SSD Method", "check_type": "numeric"},
    "specific_gravity": {"min_allowed": 2.6, "max_allowed": 2.9, "standard_ref": "IS 2386 Part III (placeholder)", "test_method": "Pycnometer Method", "check_type": "numeric"},
}
