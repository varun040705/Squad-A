# materials/paints/config.py -- STARTER DEPTH. PLACEHOLDER thresholds.
PAINTS_CONFIG = {
    "viscosity": {"unit": "KU", "min_allowed": 70, "max_allowed": 100, "standard_ref": "ASTM D562 (placeholder)", "test_method": "Krebs Viscometer", "check_type": "numeric"},
    "drying_time": {"unit": "hr", "max_allowed": 8, "standard_ref": "ASTM D1640 (placeholder)", "test_method": "Touch/Recoat Test", "check_type": "numeric"},
    "coverage_rate": {"unit": "m2/L", "min_allowed": 10, "standard_ref": "Manufacturer Spec (placeholder)", "test_method": "Application Test", "check_type": "numeric"},
    "adhesion_test": {"standard_ref": "ASTM D3359 (placeholder)", "test_method": "Cross-Cut Adhesion Test", "check_type": "categorical", "allowed_values": ["5B", "4B"]},
}
