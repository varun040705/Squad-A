# materials/steel/config.py -- STARTER DEPTH (reinforcement bars). PLACEHOLDER thresholds.
STEEL_CONFIG = {
    "diameter_tolerance": {"unit": "%", "min_allowed": -2, "max_allowed": 2, "standard_ref": "IS 1786 (placeholder)", "test_method": "Micrometer Measurement", "check_type": "numeric"},
    "yield_strength": {"unit": "MPa", "min_allowed": 415, "standard_ref": "IS 1786 (placeholder)", "test_method": "Tensile Test", "check_type": "numeric"},
    "ultimate_tensile_strength": {"unit": "MPa", "min_allowed": 485, "standard_ref": "IS 1786 (placeholder)", "test_method": "Tensile Test", "check_type": "numeric"},
    "elongation": {"unit": "%", "min_allowed": 12, "standard_ref": "IS 1786 (placeholder)", "test_method": "Tensile Test", "check_type": "numeric"},
    "bend_test_result": {"standard_ref": "IS 1786 (placeholder)", "test_method": "Bend/Rebend Test", "check_type": "categorical", "allowed_values": ["No Cracks"]},
    "mill_test_certificate": {"standard_ref": "Manufacturer Certificate", "test_method": "Document Verification", "check_type": "boolean"},
}
