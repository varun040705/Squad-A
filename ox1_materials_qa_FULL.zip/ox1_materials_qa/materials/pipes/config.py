# materials/pipes/config.py -- STARTER DEPTH. PLACEHOLDER thresholds.
PIPES_CONFIG = {
    "pressure_rating": {"unit": "bar", "min_allowed": 6, "standard_ref": "IS 4985 (placeholder)", "test_method": "Hydrostatic Pressure Test", "check_type": "numeric"},
    "diameter_tolerance": {"unit": "mm", "min_allowed": -1, "max_allowed": 1, "standard_ref": "IS 4985 (placeholder)", "test_method": "Physical Measurement", "check_type": "numeric"},
    "wall_thickness": {"unit": "mm", "min_allowed": 2.0, "standard_ref": "IS 4985 (placeholder)", "test_method": "Micrometer Measurement", "check_type": "numeric"},
    "leak_test": {"standard_ref": "Site QA Checklist", "test_method": "Pressure Leak Test", "check_type": "boolean"},
}
