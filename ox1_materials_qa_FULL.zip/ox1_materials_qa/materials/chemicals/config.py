# materials/chemicals/config.py -- STARTER DEPTH (admixtures). PLACEHOLDER thresholds.
CHEMICALS_CONFIG = {
    "concentration": {"unit": "%", "min_allowed": 95, "standard_ref": "IS 9103 (placeholder)", "test_method": "Chemical Analysis", "check_type": "numeric"},
    "ph_value": {"min_allowed": 6, "max_allowed": 8, "standard_ref": "IS 9103 (placeholder)", "test_method": "pH Meter", "check_type": "numeric"},
    "shelf_life_valid": {"standard_ref": "Manufacturer Spec", "test_method": "Date Verification", "check_type": "boolean"},
    "compatibility_certificate": {"standard_ref": "Manufacturer Certificate", "test_method": "Document Verification", "check_type": "boolean"},
}
