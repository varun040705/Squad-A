# materials/tiles/config.py -- STARTER DEPTH. PLACEHOLDER thresholds.
TILES_CONFIG = {
    "water_absorption": {"unit": "%", "max_allowed": 0.5, "standard_ref": "ASTM C373 (placeholder)", "test_method": "Boiling Water Method", "check_type": "numeric"},
    "breaking_strength": {"unit": "N", "min_allowed": 1300, "standard_ref": "ASTM C648 (placeholder)", "test_method": "Breaking Strength Test", "check_type": "numeric"},
    "dimensional_tolerance": {"unit": "mm", "min_allowed": -2, "max_allowed": 2, "standard_ref": "ISO 13006 (placeholder)", "test_method": "Physical Measurement", "check_type": "numeric"},
    "surface_quality": {"standard_ref": "ISO 13006 (placeholder)", "test_method": "Visual Inspection", "check_type": "categorical", "allowed_values": ["No Defects", "Minor Defects"]},
}
