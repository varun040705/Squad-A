# materials/hvac_components/config.py -- STARTER DEPTH. PLACEHOLDER thresholds.
HVAC_COMPONENTS_CONFIG = {
    "airflow_rating": {"unit": "CFM", "min_allowed": 100, "standard_ref": "ASHRAE (placeholder)", "test_method": "Airflow Measurement", "check_type": "numeric"},
    "duct_leakage": {"unit": "%", "max_allowed": 5, "standard_ref": "SMACNA (placeholder)", "test_method": "Duct Leakage Test", "check_type": "numeric"},
    "insulation_thickness": {"unit": "mm", "min_allowed": 25, "standard_ref": "ASHRAE (placeholder)", "test_method": "Thickness Gauge", "check_type": "numeric"},
}
