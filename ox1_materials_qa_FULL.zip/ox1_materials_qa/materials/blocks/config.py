# materials/blocks/config.py -- STARTER DEPTH (concrete blocks). PLACEHOLDER thresholds.
BLOCKS_CONFIG = {
    "compressive_strength": {"unit": "MPa", "min_allowed": 4.0, "standard_ref": "IS 2185 (placeholder)", "test_method": "Compression Test", "check_type": "numeric"},
    "dimensional_tolerance": {"unit": "mm", "min_allowed": -5, "max_allowed": 5, "standard_ref": "IS 2185 (placeholder)", "test_method": "Physical Measurement", "check_type": "numeric"},
    "water_absorption": {"unit": "%", "max_allowed": 10, "standard_ref": "IS 2185 (placeholder)", "test_method": "24hr Immersion Test", "check_type": "numeric"},
    "density": {"unit": "kg/m3", "min_allowed": 1500, "standard_ref": "IS 2185 (placeholder)", "test_method": "Mass/Volume Method", "check_type": "numeric"},
}
