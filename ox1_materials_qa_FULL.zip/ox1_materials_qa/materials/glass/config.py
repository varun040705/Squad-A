# materials/glass/config.py -- STARTER DEPTH. PLACEHOLDER thresholds.
GLASS_CONFIG = {
    "thickness_tolerance": {"unit": "mm", "min_allowed": -0.2, "max_allowed": 0.2, "standard_ref": "IS 2835 (placeholder)", "test_method": "Micrometer Measurement", "check_type": "numeric"},
    "visual_defects": {"standard_ref": "IS 2835 (placeholder)", "test_method": "Visual Inspection", "check_type": "categorical", "allowed_values": ["No Defects", "Minor"]},
    "impact_resistance": {"standard_ref": "IS 2553 (placeholder)", "test_method": "Impact Test", "check_type": "categorical", "allowed_values": ["Pass"]},
}
