# materials/cement/config.py -- STARTER DEPTH (5 core parameters). PLACEHOLDER thresholds.
CEMENT_CONFIG = {
    "fineness_blaine": {"unit": "m2/kg", "min_allowed": 225, "standard_ref": "IS 4031 (placeholder)", "test_method": "Blaine Air Permeability", "check_type": "numeric"},
    "initial_setting_time": {"unit": "min", "min_allowed": 30, "standard_ref": "IS 4031 (placeholder)", "test_method": "Vicat Apparatus", "check_type": "numeric"},
    "final_setting_time": {"unit": "min", "max_allowed": 600, "standard_ref": "IS 4031 (placeholder)", "test_method": "Vicat Apparatus", "check_type": "numeric"},
    "compressive_strength_28day": {"unit": "MPa", "min_allowed": 33, "standard_ref": "IS 4031 (placeholder)", "test_method": "Cube Compression Test", "check_type": "numeric"},
    "soundness_expansion": {"unit": "mm", "max_allowed": 10, "standard_ref": "IS 4031 (placeholder)", "test_method": "Le Chatelier Method", "check_type": "numeric"},
    "batch_traceability": {"standard_ref": "Manufacturer Certificate", "test_method": "Document Verification", "check_type": "boolean"},
}
