# materials/bricks/config.py -- STARTER DEPTH. PLACEHOLDER thresholds.
BRICKS_CONFIG = {
    "compressive_strength": {"unit": "MPa", "min_allowed": 3.5, "standard_ref": "IS 3495 (placeholder)", "test_method": "Compression Test", "check_type": "numeric"},
    "water_absorption": {"unit": "%", "max_allowed": 20, "standard_ref": "IS 3495 (placeholder)", "test_method": "24hr Immersion Test", "check_type": "numeric"},
    "dimensional_tolerance": {"unit": "mm", "min_allowed": -3, "max_allowed": 3, "standard_ref": "IS 1077 (placeholder)", "test_method": "Physical Measurement", "check_type": "numeric"},
    "efflorescence": {"standard_ref": "IS 3495 (placeholder)", "test_method": "Efflorescence Test", "check_type": "categorical", "allowed_values": ["Nil", "Slight"]},
}
