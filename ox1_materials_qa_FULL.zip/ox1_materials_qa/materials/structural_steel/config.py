# materials/structural_steel/config.py -- STARTER DEPTH (fabricated members). PLACEHOLDER thresholds.
STRUCTURAL_STEEL_CONFIG = {
    "dimensional_tolerance": {"unit": "mm", "min_allowed": -3, "max_allowed": 3, "standard_ref": "IS 800 (placeholder)", "test_method": "Physical Measurement", "check_type": "numeric"},
    "weld_quality": {"standard_ref": "AWS D1.1 (placeholder)", "test_method": "Visual + UT Weld Inspection", "check_type": "categorical", "allowed_values": ["Accept"]},
    "surface_treatment": {"standard_ref": "IS 1477 (placeholder)", "test_method": "Coating Inspection", "check_type": "categorical", "allowed_values": ["Compliant"]},
    "mill_test_certificate": {"standard_ref": "Manufacturer Certificate", "test_method": "Document Verification", "check_type": "boolean"},
}
