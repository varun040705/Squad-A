# materials/sand/calculations.py -- derived-value formulas for Sand

def calculate_fineness_modulus(cumulative_percent_retained):
    if len(cumulative_percent_retained) != 6:
        raise ValueError("Expected 6 cumulative % retained values")
    return round(sum(cumulative_percent_retained) / 100, 2)

def calculate_specific_gravity(dry_weight, pycnometer_water_weight, pycnometer_sample_water_weight):
    denominator = pycnometer_water_weight + dry_weight - pycnometer_sample_water_weight
    if denominator <= 0:
        raise ValueError("Invalid weights")
    return round(dry_weight / denominator, 2)

def calculate_water_absorption(saturated_surface_dry_weight, oven_dry_weight):
    if oven_dry_weight <= 0:
        raise ValueError("Oven dry weight must be positive")
    return round(((saturated_surface_dry_weight - oven_dry_weight) / oven_dry_weight) * 100, 2)

def calculate_bulk_density(mass_kg, volume_m3):
    if volume_m3 <= 0:
        raise ValueError("Volume must be positive")
    return round(mass_kg / volume_m3, 1)
