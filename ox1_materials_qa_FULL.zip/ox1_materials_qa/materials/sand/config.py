# materials/sand/config.py
# All threshold values are PLACEHOLDERS -- verify against IS 383 / ASTM C33.
# FULL DEPTH: all 14 Key Acceptance Parameters (this material was built out completely).

SAND_CONFIG = {
    "silt_clay_content": {"unit": "%", "max_allowed": 8.0, "standard_ref": "IS 383 (placeholder)", "test_method": "Field Silt Test", "check_type": "numeric"},
    "moisture_content": {"unit": "%", "max_allowed": 5.0, "standard_ref": "IS 2386 (placeholder)", "test_method": "Oven Drying", "check_type": "numeric"},
    "fineness_modulus": {"unit": None, "min_allowed": 2.2, "max_allowed": 3.2, "standard_ref": "IS 383 (placeholder)", "test_method": "Sieve Analysis", "check_type": "numeric"},
    "chloride_content": {"unit": "%", "max_allowed": 0.06, "standard_ref": "IS 383 (placeholder)", "test_method": "Chemical Analysis", "check_type": "numeric"},
    "sulfate_content": {"unit": "%", "max_allowed": 0.4, "standard_ref": "IS 383 (placeholder)", "test_method": "Chemical Analysis", "check_type": "numeric"},
    "material_finer_75micron": {"unit": "%", "max_allowed": 3.0, "standard_ref": "IS 383 (placeholder)", "test_method": "Wet Sieve Analysis", "check_type": "numeric"},
    "specific_gravity": {"unit": None, "min_allowed": 2.5, "max_allowed": 2.8, "standard_ref": "IS 2386 Part III (placeholder)", "test_method": "Pycnometer Method", "check_type": "numeric"},
    "water_absorption": {"unit": "%", "max_allowed": 2.0, "standard_ref": "IS 2386 Part III (placeholder)", "test_method": "SSD Method", "check_type": "numeric"},
    "bulk_density": {"unit": "kg/m3", "min_allowed": 1450, "max_allowed": 1650, "standard_ref": "IS 2386 Part III (placeholder)", "test_method": "Bulk Density Method", "check_type": "numeric"},
    "organic_impurities": {"standard_ref": "IS 2386 Part II (placeholder)", "test_method": "Colorimetric Test", "check_type": "categorical", "allowed_values": ["No.1", "No.2"]},
    "particle_shape_angularity": {"standard_ref": "IS 2386 Part I (placeholder)", "test_method": "Visual Assessment", "check_type": "categorical", "allowed_values": ["Rounded", "Sub-rounded", "Sub-angular"]},
    "source_approval": {"standard_ref": "Vendor Qualification Register", "test_method": "Document Verification", "check_type": "boolean"},
    "gradation": {"standard_ref": "IS 383 Zone II (placeholder)", "test_method": "Sieve Analysis % Passing", "check_type": "gradation",
        "zone_limits": {"10mm": (100, 100), "4.75mm": (90, 100), "2.36mm": (75, 100), "1.18mm": (55, 90), "600um": (35, 59), "300um": (8, 30), "150um": (0, 10)}},
}
