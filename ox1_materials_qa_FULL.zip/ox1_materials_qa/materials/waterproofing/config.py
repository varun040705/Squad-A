# materials/waterproofing/config.py -- STARTER DEPTH (membrane). PLACEHOLDER thresholds.
WATERPROOFING_CONFIG = {
    "thickness": {"unit": "mm", "min_allowed": 1.5, "standard_ref": "ASTM D5147 (placeholder)", "test_method": "Thickness Gauge", "check_type": "numeric"},
    "water_penetration_test": {"standard_ref": "ASTM D5385 (placeholder)", "test_method": "Hydrostatic Pressure Test", "check_type": "categorical", "allowed_values": ["No Penetration"]},
    "adhesion_strength": {"unit": "N/mm2", "min_allowed": 0.5, "standard_ref": "ASTM D903 (placeholder)", "test_method": "Peel Adhesion Test", "check_type": "numeric"},
}
