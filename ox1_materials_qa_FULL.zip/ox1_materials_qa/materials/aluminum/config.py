# materials/aluminum/config.py -- STARTER DEPTH. PLACEHOLDER thresholds.
ALUMINUM_CONFIG = {
    "thickness_tolerance": {"unit": "mm", "min_allowed": -0.1, "max_allowed": 0.1, "standard_ref": "IS 733 (placeholder)", "test_method": "Micrometer Measurement", "check_type": "numeric"},
    "surface_finish": {"standard_ref": "IS 733 (placeholder)", "test_method": "Visual Inspection", "check_type": "categorical", "allowed_values": ["No Defects"]},
    "alloy_certificate": {"standard_ref": "Manufacturer Certificate", "test_method": "Document Verification", "check_type": "boolean"},
}
