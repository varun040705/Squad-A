# main.py -- exercises EVERY material + category with a PASSING sample,
# to prove the whole scope runs end-to-end without errors.

import sys, os
sys.path.append(os.path.dirname(__file__))

from core.sample import QASample
from core.engine import run_qa

from materials.sand.config import SAND_CONFIG
from materials.sand.calculations import (
    calculate_fineness_modulus, calculate_specific_gravity,
    calculate_water_absorption, calculate_bulk_density,
)
from materials.cement.config import CEMENT_CONFIG
from materials.steel.config import STEEL_CONFIG
from materials.aggregates.config import AGGREGATES_CONFIG
from materials.bricks.config import BRICKS_CONFIG
from materials.blocks.config import BLOCKS_CONFIG
from materials.concrete.config import CONCRETE_CONFIG
from materials.tiles.config import TILES_CONFIG
from materials.waterproofing.config import WATERPROOFING_CONFIG
from materials.pipes.config import PIPES_CONFIG
from materials.electrical_materials.config import ELECTRICAL_MATERIALS_CONFIG
from materials.hvac_components.config import HVAC_COMPONENTS_CONFIG
from materials.paints.config import PAINTS_CONFIG
from materials.structural_steel.config import STRUCTURAL_STEEL_CONFIG
from materials.aluminum.config import ALUMINUM_CONFIG
from materials.glass.config import GLASS_CONFIG
from materials.chemicals.config import CHEMICALS_CONFIG

from procurement.config import PROCUREMENT_CONFIG
from manufacturing.config import MANUFACTURING_CONFIG
from onsite.config import ONSITE_CONFIG


def run_and_report(label, config, sample):
    report = run_qa(config, sample)
    status = report["overall_status"]
    marker = "PASS" if status == "PASS" else "FAIL"
    print(f"[{marker}] {label:28s} -> overall_status={status}  ({len(report['results'])} items checked)")
    return report


results_summary = []

# ---- Sand (full depth, with real derived calculations) ----
fm = calculate_fineness_modulus([2, 12, 35, 65, 88, 97])
sg = calculate_specific_gravity(500, 1500, 1810)
wa = calculate_water_absorption(510, 500)
bd = calculate_bulk_density(1.55, 0.001)
sand_sample = QASample("SND-2026-001", "River Sand - Vendor X", {
    "silt_clay_content": 6.2, "moisture_content": 4.1, "fineness_modulus": fm,
    "chloride_content": 0.03, "sulfate_content": 0.2, "material_finer_75micron": 2.0,
    "specific_gravity": sg, "water_absorption": wa, "bulk_density": bd,
    "organic_impurities": "No.1", "particle_shape_angularity": "Sub-angular",
    "source_approval": True,
    "gradation": {"10mm": 100, "4.75mm": 95, "2.36mm": 85, "1.18mm": 70, "600um": 45, "300um": 15, "150um": 5},
})
results_summary.append(run_and_report("Sand", SAND_CONFIG, sand_sample))

# ---- Cement ----
cement_sample = QASample("CEM-2026-001", "OPC 43 Grade - Vendor A", {
    "fineness_blaine": 260, "initial_setting_time": 45, "final_setting_time": 480,
    "compressive_strength_28day": 43, "soundness_expansion": 5, "batch_traceability": True,
})
results_summary.append(run_and_report("Cement", CEMENT_CONFIG, cement_sample))

# ---- Steel ----
steel_sample = QASample("STL-2026-001", "TMT Fe500 - Vendor B", {
    "diameter_tolerance": 0.5, "yield_strength": 520, "ultimate_tensile_strength": 610,
    "elongation": 16, "bend_test_result": "No Cracks", "mill_test_certificate": True,
})
results_summary.append(run_and_report("Steel", STEEL_CONFIG, steel_sample))

# ---- Aggregates ----
agg_sample = QASample("AGG-2026-001", "20mm Coarse Aggregate - Vendor C", {
    "crushing_value": 22, "impact_value": 20, "flakiness_index": 25,
    "elongation_index": 28, "water_absorption": 1.2, "specific_gravity": 2.7,
})
results_summary.append(run_and_report("Aggregates", AGGREGATES_CONFIG, agg_sample))

# ---- Bricks ----
bricks_sample = QASample("BRK-2026-001", "Clay Bricks - Vendor D", {
    "compressive_strength": 5.5, "water_absorption": 15, "dimensional_tolerance": 1, "efflorescence": "Nil",
})
results_summary.append(run_and_report("Bricks", BRICKS_CONFIG, bricks_sample))

# ---- Blocks ----
blocks_sample = QASample("BLK-2026-001", "Concrete Blocks - Vendor E", {
    "compressive_strength": 5.5, "dimensional_tolerance": 2, "water_absorption": 8, "density": 1700,
})
results_summary.append(run_and_report("Blocks", BLOCKS_CONFIG, blocks_sample))

# ---- Concrete ----
concrete_sample = QASample("CON-2026-001", "M25 Ready-Mix - Batch 12", {
    "slump": 100, "cube_strength_28day": 28, "workability": "Good", "curing_verification": True,
})
results_summary.append(run_and_report("Concrete", CONCRETE_CONFIG, concrete_sample))

# ---- Tiles ----
tiles_sample = QASample("TIL-2026-001", "Vitrified Tiles - Vendor F", {
    "water_absorption": 0.2, "breaking_strength": 1500, "dimensional_tolerance": 0.5, "surface_quality": "No Defects",
})
results_summary.append(run_and_report("Tiles", TILES_CONFIG, tiles_sample))

# ---- Waterproofing ----
wp_sample = QASample("WPR-2026-001", "Membrane - Vendor G", {
    "thickness": 2.0, "water_penetration_test": "No Penetration", "adhesion_strength": 0.8,
})
results_summary.append(run_and_report("Waterproofing", WATERPROOFING_CONFIG, wp_sample))

# ---- Pipes ----
pipes_sample = QASample("PIP-2026-001", "PVC Pipe - Vendor H", {
    "pressure_rating": 8, "diameter_tolerance": 0.3, "wall_thickness": 2.5, "leak_test": True,
})
results_summary.append(run_and_report("Pipes", PIPES_CONFIG, pipes_sample))

# ---- Electrical Materials ----
elec_sample = QASample("ELE-2026-001", "XLPE Cable - Vendor I", {
    "insulation_resistance": 2.5, "voltage_rating_confirmed": True, "continuity_test": True, "certification": True,
})
results_summary.append(run_and_report("Electrical Materials", ELECTRICAL_MATERIALS_CONFIG, elec_sample))

# ---- HVAC Components ----
hvac_sample = QASample("HVC-2026-001", "AHU Duct - Vendor J", {
    "airflow_rating": 150, "duct_leakage": 3, "insulation_thickness": 30,
})
results_summary.append(run_and_report("HVAC Components", HVAC_COMPONENTS_CONFIG, hvac_sample))

# ---- Paints ----
paints_sample = QASample("PNT-2026-001", "Exterior Emulsion - Vendor K", {
    "viscosity": 85, "drying_time": 4, "coverage_rate": 12, "adhesion_test": "5B",
})
results_summary.append(run_and_report("Paints", PAINTS_CONFIG, paints_sample))

# ---- Structural Steel ----
ss_sample = QASample("SST-2026-001", "Fabricated Beam - Vendor L", {
    "dimensional_tolerance": 1.5, "weld_quality": "Accept", "surface_treatment": "Compliant", "mill_test_certificate": True,
})
results_summary.append(run_and_report("Structural Steel", STRUCTURAL_STEEL_CONFIG, ss_sample))

# ---- Aluminum ----
al_sample = QASample("ALU-2026-001", "Aluminum Sheet - Vendor M", {
    "thickness_tolerance": 0.05, "surface_finish": "No Defects", "alloy_certificate": True,
})
results_summary.append(run_and_report("Aluminum", ALUMINUM_CONFIG, al_sample))

# ---- Glass ----
glass_sample = QASample("GLS-2026-001", "Toughened Glass - Vendor N", {
    "thickness_tolerance": 0.1, "visual_defects": "No Defects", "impact_resistance": "Pass",
})
results_summary.append(run_and_report("Glass", GLASS_CONFIG, glass_sample))

# ---- Chemicals ----
chem_sample = QASample("CHM-2026-001", "Superplasticizer - Vendor O", {
    "concentration": 97, "ph_value": 7, "shelf_life_valid": True, "compatibility_certificate": True,
})
results_summary.append(run_and_report("Chemicals", CHEMICALS_CONFIG, chem_sample))

print()

# ---- Procurement ----
proc_sample = QASample("PO-2026-014", "Vendor A Delivery", {
    "vendor_approved": True, "po_verified": True, "sample_approved": True,
    "delivery_on_time": True, "packaging_intact": True, "documentation_complete": True,
})
results_summary.append(run_and_report("Procurement QA", PROCUREMENT_CONFIG, proc_sample))

# ---- Manufacturing ----
mfg_sample = QASample("MFG-2026-007", "Precast Panel Batch 7", {
    "dimensional_tolerance": 1.5, "factory_production_control_certified": True,
    "weld_quality": "Accept", "surface_treatment_qa": "Compliant", "factory_test_report_available": True,
})
results_summary.append(run_and_report("Manufacturing QA", MANUFACTURING_CONFIG, mfg_sample))

# ---- On-site ----
onsite_sample = QASample("SITE-2026-023", "Block A, Level 3 Pour", {
    "concrete_slump": 90, "concrete_cube_strength": 27, "reinforcement_bar_spacing": 150,
    "reinforcement_cover": 30, "formwork_alignment_deviation": 3, "masonry_plumbness_deviation": 4,
})
results_summary.append(run_and_report("On-Site Construction", ONSITE_CONFIG, onsite_sample))

print()
total = len(results_summary)
passed = sum(1 for r in results_summary if r["overall_status"] == "PASS")
print(f"SUMMARY: {passed}/{total} modules ran and returned overall_status=PASS on sample data")
