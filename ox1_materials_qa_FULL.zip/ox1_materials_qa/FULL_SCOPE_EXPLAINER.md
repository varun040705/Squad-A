# OUANTUM — Materials & Construction QA (Member 2) — Full Scope Handoff

## What this is
Every module Member 2 owns — 17 construction materials, Procurement QA,
Manufacturing QA, and On-Site Construction QA — built on one shared,
generic engine. Every module is real, runnable, and tested (both PASS and
FAIL paths confirmed working).

## Architecture
- **core/sample.py** — `QASample`: generic container for any sample/event
  (a material delivery, a purchase order, a site inspection).
- **core/checks.py** — 4 generic check types, used identically everywhere:
  `numeric` (min/max), `categorical` (allowed value list), `boolean`
  (yes/no confirmation), `gradation` (sieve curve vs. zone limits).
- **core/engine.py** — `run_qa(config, sample)`: takes ANY config + ANY
  sample, runs every item's check, returns one report. This one function
  powers all 20 modules below — nothing material-specific lives here.
- **materials/<name>/config.py** — one file per material, pure data:
  thresholds, standard refs, test methods, check type per item.
- **procurement/config.py, manufacturing/config.py, onsite/config.py** —
  same pattern, for the three non-material categories.

Adding a new material or item going forward means writing a config
dictionary — never touching `core/`.

## Depth: Sand vs. everything else (read this before integrating)
- **Sand — FULL DEPTH.** All 14 Key Acceptance Parameters, including
  derived-value calculations (Fineness Modulus, Specific Gravity, Water
  Absorption, Bulk Density computed from raw test data, not typed in).
  This is the reference standard for what "complete" looks like.
- **The other 16 materials + Procurement + Manufacturing + On-Site —
  STARTER DEPTH.** Each has 3–6 of its most critical QA parameters,
  chosen from standard industry QA practice for that material/category.
  These are NOT exhaustive — they prove the interface and catch the
  obvious failures, but they are a first pass, not the final word.

## What every "STARTER DEPTH" config needs before it's Sand-level complete
1. Expand to the full parameter list for that material (see the QA
   taxonomy doc for each material's complete inspection scope).
2. Replace ALL placeholder threshold values with verified IS/ASTM/BS
   numbers — every single number in every config right now is a
   PLACEHOLDER, clearly commented as such.
3. Add derived-value calculations where the real test produces raw data
   rather than a single number (same pattern as Sand's
   `calculations.py`) — likely needed for Aggregates (crushing/impact
   value math), Concrete (mix ratios), and others.
4. Confirm which grading zone / standard variant applies where a
   placeholder assumption was made (e.g. Sand's gradation uses IS 383
   Zone II — confirm this is the right zone for OX1's actual use case).

## Proof it works
`main.py` runs all 20 modules (17 materials + 3 categories) against
realistic PASS-case sample data — all 20 return `overall_status: PASS`.
The generic engine was also verified against deliberately bad data for
Cement and On-Site checks — both correctly returned `overall_status:
FAIL` with the right failing items named, confirming the failure path
works across the shared engine, not just for Sand.

## For the other team integrating today
- Every module's `run_qa(config, sample)` call returns the same report
  shape: `sample_id`, `source`, `results` (list of per-item results),
  `overall_status` (PASS/FAIL).
- Treat all threshold numbers as provisional — they demonstrate the
  mechanism, not verified acceptance criteria yet.
- `main.py` is the reference for exactly how to construct a sample and
  call each module.
